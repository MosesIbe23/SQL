
-- Select Statements

-- Get the artist who made the song 'Save Your Tears'.

SELECT first_name, last_name
 FROM artist
 WHERE artist_id =
	(SELECT artist_id
    FROM band_or_artist_has_song
    WHERE song_id = 
		(SELECT song_id
		FROM song 
		WHERE song_name = 'Save Your Tears'));

-- Get the album that contain the song 'Levitating'.

SELECT album_name
FROM album
WHERE album_id IN (
    SELECT album_id
    FROM album_has_song
    WHERE song_id = 
		(SELECT song_id 
		FROM song
		WHERE song_name = 'Levitating')
);

-- List the digital rights and genre for the song 'Blinding Lights'.

SELECT dr.rights_name, g.genre
FROM digital_rights dr
JOIN song_rights sr ON dr.digital_rights_id = sr.digital_rights_id
JOIN genre g ON sr.genre_id = g.genre_id
WHERE sr.song_id = 
	(SELECT song_id 
    FROM song 
    WHERE song_name = 'Blinding Lights');

-- Retrieve all sponsors associated with Canadian artists.

SELECT s.primary_sponsor
FROM sponsors s
JOIN nationality_has_sponsors nhs ON s.sponsors_id = nhs.sponsors_id
WHERE nhs.nationality_id = 
	(SELECT nationality_id 
    FROM nationality 
    WHERE nationality = 'Canadian');

