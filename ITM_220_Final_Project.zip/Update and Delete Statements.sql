
-- Updates the number_of_streams and rank_number for the songs.

UPDATE song
SET
    number_of_streams = CASE
        WHEN song_name = 'Blinding Lights' THEN '4.0B'
        WHEN song_name = 'Save Your Tears' THEN '2.5B'
        WHEN song_name = 'Levitating' THEN '2.0B'
        ELSE number_of_streams
    END,
    rank_number = CASE
        WHEN song_name = 'Blinding Lights' THEN 1
        WHEN song_name = 'Save Your Tears' THEN 2
        WHEN song_name = 'Levitating' THEN 3
        ELSE rank_number
    END
WHERE song_name IN ('Blinding Lights', 'Save Your Tears', 'Levitating');

-- Update the number of streams for a specific song.

UPDATE song
SET number_of_streams = '3.6B'
WHERE song_name = 'Blinding Lights';

-- Update statements for `band`.

SET @bandnumber = 1;
SET @bandname = 'The Weekend';

UPDATE band
SET band_name = @bandname WHERE band_id = @bandnumber; 

SET @bandnumber = 2;
SET @bandname = 'AGB';

UPDATE band
SET band_name = @bandname WHERE band_id = @bandnumber; 

SET @bandnumber = 3;
SET @bandname = 'Dua Lipa';

UPDATE band
SET band_name = @bandname WHERE band_id = @bandnumber; 


-- Delete Statement 1

CREATE TEMPORARY TABLE temp_song_r AS
SELECT song_id
FROM song
WHERE rank_number = 3;

DELETE FROM temp_song_r
WHERE song_id IN 
	(SELECT song_id 
    FROM song 
    WHERE rank_number = 3);

DROP TABLE temp_song_r;

-- Delete Statement 2

CREATE TEMPORARY TABLE temp_artist_ids AS
SELECT artist_id
FROM artist
WHERE first_name = 'Abel';

DELETE FROM band_or_artist_has_song
WHERE artist_id IN
	(SELECT artist_id 
    FROM temp_artist_ids);

DROP TEMPORARY TABLE temp_artist_ids;

-- Delete Statement 3

DELETE song_rights
FROM song_rights
JOIN genre ON song_rights.genre_id = genre.genre_id
WHERE genre.genre = 'Disco-Pop';

drop schema top_artist;


