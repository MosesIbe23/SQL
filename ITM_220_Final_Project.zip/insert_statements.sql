
-- The Beginning

use top_artist;

-- Insert statements for `year`
INSERT INTO `year`
(   
    year_released,
    month_released
)
VALUES
    (2019, 'November'),
    (2021, 'January'),
    (2020, 'March');

-- Insert statements for `album`
INSERT INTO `album`
(
    album_name,
    number_of_songs
)
VALUES
    ('After Hours', 14),
    ('Positions', 14),
    ('Future Nostalgia', 11);

-- Insert statements for `artist`
INSERT INTO `artist`
(
    first_name,
    last_name
)
VALUES
    ('Abel', 'Tesfaye'),
    ('Ariana', 'Grande'),
    ('Dukagjin', 'Lipa');

-- Insert statements for `sponsors`
INSERT INTO `sponsors`
(
    primary_sponsor
)
VALUES
    ('Stuart Price'),
    ('Max Martin'),
    ('Oscar Holter');

-- Insert statements for `song`
INSERT INTO `song`
(
    song_id,
    song_name,
    rank_number,
    number_of_streams
)
VALUES
    (default, 'Blinding Lights', 1, '3.5B'),
    (default, 'Save Your Tears', 2, '2.1B'),
    (default, 'Levitating', 3, '1.8B');

-- Insert statements for `digital_rights`
INSERT INTO `digital_rights`
(
    digital_rights_id,
    rights_name
)
VALUES
    (1, 'Warner'),
    (2, 'Republic Records1'),
    (3, 'Republic Records2');

-- Insert statements for `genre`
INSERT INTO `genre`
(
    genre_id,
    genre
)
VALUES
    (default, 'Synthwave'), 
    (default, 'Pop'), 
    (default, 'Disco-Pop');

-- Insert statements for `song_rights`
INSERT INTO `song_rights`
(
    digital_rights_id,
    song_id,
    genre_id
)
VALUES
    ((SELECT digital_rights_id FROM digital_rights WHERE rights_name = 'Warner'),
    (SELECT song_id FROM song WHERE song_name = 'Blinding Lights'),
    (SELECT genre_id FROM genre WHERE genre = 'Synthwave')),
    
    ((SELECT digital_rights_id FROM digital_rights WHERE rights_name = 'Republic Records1'),
    (SELECT song_id FROM song WHERE song_name = 'Save Your Tears'),
    (SELECT genre_id FROM genre WHERE genre = 'Pop')),
    
    ((SELECT digital_rights_id FROM digital_rights WHERE rights_name = 'Republic Records2'),
    (SELECT song_id FROM song WHERE song_name = 'Levitating'),
    (SELECT genre_id FROM genre WHERE genre = 'Disco-Pop'));

-- Insert statements for `nationality`
INSERT INTO `nationality`
(
    nationality_id,
    nationality,
    band_or_artist_id,
    is_primary
)
VALUES
    (default, 'Canadian', (SELECT artist_id FROM artist WHERE first_name = 'Abel' AND last_name = 'Tesfaye'), 'Y'),
    (default, 'American', (SELECT artist_id FROM artist WHERE first_name = 'Ariana' AND last_name = 'Grande'), 'Y'),
    (default, 'British', (SELECT artist_id FROM artist WHERE first_name = 'Dukagjin' AND last_name = 'Lipa'), 'Y');

-- Insert statements for `nationality_has_sponsors`
INSERT INTO `nationality_has_sponsors`
(
    nationality_id,
    sponsors_id
)
VALUES
    ((SELECT nationality_id FROM nationality WHERE nationality = 'Canadian'), (SELECT sponsors_id FROM sponsors WHERE primary_sponsor = 'Stuart Price')),
    ((SELECT nationality_id FROM nationality WHERE nationality = 'American'), (SELECT sponsors_id FROM sponsors WHERE primary_sponsor = 'Max Martin')),
    ((SELECT nationality_id FROM nationality WHERE nationality = 'British'), (SELECT sponsors_id FROM sponsors WHERE primary_sponsor = 'Oscar Holter'));

-- Insert statements for `band_or_artist_has_song`
INSERT INTO `band_or_artist_has_song`
(
    artist_id,
    song_id
)
VALUES
    ((SELECT artist_id FROM artist WHERE first_name = 'Abel' AND last_name = 'Tesfaye'), (SELECT song_id FROM song WHERE rank_number = 1)),
    ((SELECT artist_id FROM artist WHERE first_name = 'Ariana' AND last_name = 'Grande'), (SELECT song_id FROM song WHERE rank_number = 2)),
    ((SELECT artist_id FROM artist WHERE first_name = 'Dukagjin' AND last_name = 'Lipa'), (SELECT song_id FROM song WHERE rank_number = 3));

-- Insert statements for `song_has_year`
INSERT INTO `song_has_year`
(
    song_id,
    year_id
)
VALUES
    ((SELECT song_id FROM song WHERE rank_number = 1), (SELECT year_id FROM year WHERE year_released = 2019)),
    ((SELECT song_id FROM song WHERE rank_number = 2), (SELECT year_id FROM year WHERE year_released = 2021)),
    ((SELECT song_id FROM song WHERE rank_number = 3), (SELECT year_id FROM year WHERE year_released = 2020));

-- Insert statements for `band`
INSERT INTO `band`
(
	band_id,
    band_name,
    number_of_artist,
    artist_id
)
VALUES
    (default, 'Band A', 4, (SELECT artist_id FROM artist WHERE first_name = 'Abel' AND last_name = 'Tesfaye')),
    (default, 'Band B', 5, (SELECT artist_id FROM artist WHERE first_name = 'Ariana' AND last_name = 'Grande')),
    (default, 'Band C', 3, (SELECT artist_id FROM artist WHERE first_name = 'Dukagjin' AND last_name = 'Lipa'));

-- Insert statements for `album_has-song`
INSERT INTO `album_has_song`
(
    album_id,
    song_id
)
VALUES
    ((SELECT album_id FROM album WHERE album_name = 'After Hours'), (SELECT song_id FROM song WHERE rank_number = 1)),
    ((SELECT album_id FROM album WHERE album_name = 'Positions'), (SELECT song_id FROM song WHERE rank_number = 2)),
    ((SELECT album_id FROM album WHERE album_name = 'Future Nostalgia'), (SELECT song_id FROM song WHERE rank_number = 3));
    
-- The End
