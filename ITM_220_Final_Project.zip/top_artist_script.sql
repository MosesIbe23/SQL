
-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema top_artist
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `top_artist` ;

-- -----------------------------------------------------
-- Schema top_artist
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `top_artist` DEFAULT CHARACTER SET utf8 ;
USE `top_artist` ;

-- -----------------------------------------------------
-- Table `top_artist`.`year`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`year` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`year` (
  `year_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `year_released` YEAR NOT NULL,
  `month_released` VARCHAR(45) NULL,
  PRIMARY KEY (`year_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`album`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`album` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`album` (
  `album_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `album_name` VARCHAR(45) NOT NULL,
  `number_of_songs` INT NULL,
  PRIMARY KEY (`album_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`artist`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`artist` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`artist` (
  `artist_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NULL,
  PRIMARY KEY (`artist_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`sponsors`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`sponsors` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`sponsors` (
  `sponsors_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `primary_sponsor` VARCHAR(90) NOT NULL,
  `other_sponsors` VARCHAR(90) NULL,
  PRIMARY KEY (`sponsors_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`song`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`song` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`song` (
  `song_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `song_name` VARCHAR(90) NOT NULL,
  `rank_number` INT NOT NULL,
  `number_of_streams` VARCHAR(45) NULL,
  PRIMARY KEY (`song_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`genre`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`genre` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`genre` (
  `genre_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `genre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`genre_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`nationality`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`nationality` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`nationality` (
  `nationality_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nationality` VARCHAR(45) NOT NULL,
  `band_or_artist_id` INT UNSIGNED NOT NULL,
  `is_primary` CHAR(1) NOT NULL,
  PRIMARY KEY (`nationality_id`),
  INDEX `fk_nationality_band or artist1_idx` (`band_or_artist_id` ASC) VISIBLE,
  CONSTRAINT `fk_nationality_band or artist1`
    FOREIGN KEY (`band_or_artist_id`)
    REFERENCES `top_artist`.`artist` (`artist_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`nationality_has_sponsors`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`nationality_has_sponsors` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`nationality_has_sponsors` (
  `nationality_id` INT UNSIGNED NOT NULL,
  `sponsors_id` INT UNSIGNED NOT NULL,
  INDEX `fk_nationality_has_sponsors_nationality1_idx` (`nationality_id` ASC) VISIBLE,
  INDEX `fk_nationality_has_sponsors_sponsors1_idx` (`sponsors_id` ASC) VISIBLE,
  CONSTRAINT `fk_nationality_has_sponsors_nationality1`
    FOREIGN KEY (`nationality_id`)
    REFERENCES `top_artist`.`nationality` (`nationality_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_nationality_has_sponsors_sponsors1`
    FOREIGN KEY (`sponsors_id`)
    REFERENCES `top_artist`.`sponsors` (`sponsors_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`band_or_artist_has_song`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`band_or_artist_has_song` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`band_or_artist_has_song` (
  `artist_id` INT UNSIGNED NOT NULL,
  `song_id` INT UNSIGNED NOT NULL,
  INDEX `fk_band or artist_has_song_artist1_idx` (`artist_id` ASC) VISIBLE,
  INDEX `fk_band or artist_has_song_song1_idx` (`song_id` ASC) VISIBLE,
  CONSTRAINT `fk_band or artist_has_song_artist1`
    FOREIGN KEY (`artist_id`)
    REFERENCES `top_artist`.`artist` (`artist_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_band or artist_has_song_song1`
    FOREIGN KEY (`song_id`)
    REFERENCES `top_artist`.`song` (`song_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`song_has_year`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`song_has_year` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`song_has_year` (
  `song_id` INT UNSIGNED NOT NULL,
  `year_id` INT UNSIGNED NOT NULL,
  INDEX `fk_song_has_year_song1_idx` (`song_id` ASC) VISIBLE,
  INDEX `fk_song_has_year_year1_idx` (`year_id` ASC) VISIBLE,
  CONSTRAINT `fk_song_has_year_song1`
    FOREIGN KEY (`song_id`)
    REFERENCES `top_artist`.`song` (`song_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_song_has_year_year1`
    FOREIGN KEY (`year_id`)
    REFERENCES `top_artist`.`year` (`year_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`band`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`band` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`band` (
  `band_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `band_name` VARCHAR(90) NOT NULL,
  `number_of_artist` INT UNSIGNED NULL,
  `artist_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`band_id`),
  INDEX `fk_band_artist1_idx` (`artist_id` ASC) VISIBLE,
  CONSTRAINT `fk_band_artist1`
    FOREIGN KEY (`artist_id`)
    REFERENCES `top_artist`.`artist` (`artist_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`digital_rights`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`digital_rights` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`digital_rights` (
  `digital_rights_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `rights_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`digital_rights_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`song_rights`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`song_rights` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`song_rights` (
  `song_id` INT UNSIGNED NOT NULL,
  `genre_id` INT UNSIGNED NOT NULL,
  `digital_rights_id` INT UNSIGNED NOT NULL,
  INDEX `fk_song_rights_song1_idx` (`song_id` ASC) VISIBLE,
  INDEX `fk_song_rights_genre1_idx` (`genre_id` ASC) VISIBLE,
  INDEX `fk_song_rights_digital_rights1_idx` (`digital_rights_id` ASC) VISIBLE,
  CONSTRAINT `fk_song_rights_song1`
    FOREIGN KEY (`song_id`)
    REFERENCES `top_artist`.`song` (`song_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_song_rights_genre1`
    FOREIGN KEY (`genre_id`)
    REFERENCES `top_artist`.`genre` (`genre_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_song_rights_digital_rights1`
    FOREIGN KEY (`digital_rights_id`)
    REFERENCES `top_artist`.`digital_rights` (`digital_rights_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `top_artist`.`album_has_song`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `top_artist`.`album_has_song` ;

CREATE TABLE IF NOT EXISTS `top_artist`.`album_has_song` (
  `album_id` INT UNSIGNED NOT NULL,
  `song_id` INT UNSIGNED NOT NULL,
  INDEX `fk_song_rights_album_album1_idx` (`album_id` ASC) VISIBLE,
  INDEX `fk_song_rights_album_song1_idx` (`song_id` ASC) VISIBLE,
  CONSTRAINT `fk_song_rights_album_album1`
    FOREIGN KEY (`album_id`)
    REFERENCES `top_artist`.`album` (`album_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_song_rights_album_song1`
    FOREIGN KEY (`song_id`)
    REFERENCES `top_artist`.`song` (`song_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
